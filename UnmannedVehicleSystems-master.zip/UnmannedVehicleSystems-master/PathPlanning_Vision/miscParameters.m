% Miscellaneous variables and constants

% Waypoint array
X_array = [];
Y_array = [];

% Sonar obstacle array
obstaclesArray = [0; 0; 0];
